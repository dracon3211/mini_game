# geometry
a simple program for calculating the area and perimeter of shapes: circle rectangle triangle 
