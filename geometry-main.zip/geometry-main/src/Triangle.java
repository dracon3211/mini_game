class Triangle implements Shape {
    private double a;
    private double b;
    private double c;

    public Triangle(double a, double b, double c) {
        this.a = a;
        this.b = b;
        this.c = c;
    }

    @Override
    public double getArea() {
        // Для прямоугольного треугольника: площадь через катеты
        return 0.5 * a * b;
    }

    @Override
    public double getPerimeter() {
        return a + b + c;
    }
}
